# ELDMA
ELDMA: An Ensemble Approach based on Multi-Source Information to predict Drug-MiRNA Associations via Convolutional Neural Networks.

Article Link: https://ieeexplore.ieee.org/abstract/document/9369317

## **Researchers can use the code with proper citation.

