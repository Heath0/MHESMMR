# BNEMDI
Source code and dataset for paper "BNEMDI: a novel multiple features integrated model for miRNA-drug interaction prediction"

A prediction model for miRNA-drug interaction based on network emebedding

